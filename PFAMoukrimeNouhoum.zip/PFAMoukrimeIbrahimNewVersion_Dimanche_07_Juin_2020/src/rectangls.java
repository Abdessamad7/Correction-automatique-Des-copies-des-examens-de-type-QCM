import java.util.ArrayList;
import java.util.List;

import org.opencv.core.*;
import org.opencv.core.Rect;
//import org.opencv.highgui.HighGui;
import org.opencv.imgcodecs.*;
import org.opencv.imgproc.Imgproc;
import org.opencv.core.Mat.*;

public class rectangls {
    /// the solution is to add opencv 4.2.0 to classpath i guess t oa problem
    ///todonext: change you javapath to 8 2.4.1 or 8.... or 13 .... or ...

    private static int i=0;
    int numberOfBox=24;
    public static void main(String[] args) {
        try {
            System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
            String filePath="/Users/nouhou/Documents/S8_FILES/PFA/ProfResourcesGmail/Resouces1FromGmailRectangle/";// this the where the ressources are
            // for it should be where the picture of the papper will be after the screeshot of  the camera; add always the "/"
//            Mat source = Imgcodecs.imread(filePath+"rectangle.jpg", Imgcodecs.IMREAD_ANYCOLOR);// transforme l'image en matrice
//            Mat resultat = Imgcodecs.imread(filePath+"rectangle.jpg", Imgcodecs.IMREAD_ANYCOLOR);// transforme l'image en matrice
            Mat source2 = Imgcodecs.imread(filePath+"jesui2.png", Imgcodecs.IMREAD_ANYCOLOR);// transforme l'image en matrice
            Mat resultat2 = Imgcodecs.imread(filePath+"jesui2.png", Imgcodecs.IMREAD_ANYCOLOR);// transforme l'image en matrice

            Mat destination = new Mat(source2.rows(), source2.cols(), source2.type());// Créer une matrice a partir du nombre de colones et et de ligne de l'image
//******************** Try to filter the countours list of point to remove the coutours from the id and the questions **************************

//            rect2  Rect_ROI = new rect2(450 ,120, 765-450, 400-120);
//            Mat destination = new Mat(source , Rect_ROI );
            Imgproc.cvtColor(source2, destination, Imgproc.COLOR_RGB2GRAY);// c'est pour rendre la source avec une couleur grey pour que toute couleur sur la feuille soit rendu gris une couleur unique
//            Imgcodecs.imwrite(filePath+"source"+ i++ +".jpg", source);
//            Imgcodecs.imwrite(filePath+"destination"+ i +".jpg", destination);


            Imgproc.equalizeHist(destination, destination);
            Imgproc.GaussianBlur(destination, destination, new Size(5, 5), 0, 0, Core.BORDER_DEFAULT);
//            Imgcodecs.imwrite(filePath+"destinationHereLine36.jpg", destination);// a ce point destination devient brouillé

            source2.copyTo(destination);
            //jusqu'ici le source n'a pas changé

            Imgproc.cvtColor(destination, destination, Imgproc.COLOR_BGR2GRAY);
            //Imgcodecs.imwrite(filePath+"destinationHereLine42.jpg", destination);// a ce point destination est comme l'image originale

            Imgproc.Canny(destination, destination, 50, 100);
            //Imgcodecs.imwrite(filePath+"destinationHereLine45.jpg", destination);
            //(***) a ce point destination devient tout noir en arrière plan mais les ecriture deviennent blancs // c'est cette image qui va etre utiliser maintenant

            int maxId = 1;
            float opt=(float)(11.6/7.3);
            //MatOfPoint sourceMat =  new MatOfPoint();
            List <MatOfPoint> contours = new ArrayList<MatOfPoint>();
            List <MatOfPoint> contoursOfCheckboxes = new ArrayList<MatOfPoint>();

            Imgproc.findContours(destination, contours, new Mat(),Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);//(***) destination n'a pas change
//            Imgcodecs.imwrite(filePath+"destinationHereLine53.jpg", destination);//
            Imgproc.cvtColor(destination, destination, Imgproc.COLOR_GRAY2BGR);//(***) destination n'a pas change
//            Imgcodecs.imwrite(filePath+"destinationHereLine56.jpg", destination);//
            float surface0 []=new float [contours.size()];// on cree un tableau de float de taille le nombre de contour pour stocker les surfaces des contours trouvé

            for(int i =0;i<contours.size();i++){
                //System.out.println(contours.get(i).toList());
                Rect rect1 = Imgproc.boundingRect(contours.get(i));// on va utiliser lelement i dans contours
                surface0[i]=(float)rect1.width*(float)rect1.height;// surface = longueur*largeur
                if (rect1.tl().x>350 && rect1.tl().y>110 && rect1.br().x<763 && rect1.br().y<390 && surface0[i]<3000  ){
                    contoursOfCheckboxes.add(contours.get(i));
                }

            }

            CutImage cutImage=new CutImage();

            float surface []=new float [contours.size()];// on cree un tableau de float de taille le nombre de contour pour stocker les surfaces des contours trouvé
            int j1=0;
            for (int i=0;i<contoursOfCheckboxes.size();i++)// on parcours l'ensembles des petits rectangles qui ont ete detecter par finsCountours  et mis dans la liste contoursOfCheckboxes
            {
                Rect rect2 = Imgproc.boundingRect(contoursOfCheckboxes.get(i));// on va utiliser lelement i dans contours
                // On remarque que le dessin des rectangles verts commence par le bas de la pages en montant.
                // Alors cela veut dire que la liste des matrices de points contours a été remplis a partir du bas.
                // et aussi du plus petits contour au plus grand. (VOIR LES IMAGES DANS LE FILEPATH)
                surface[i]=(float)rect2.width*(float)rect2.height;// surface = longueur*largeur
                if(surface[i]>400)// 50 est la surface minimale comrespondant a celle des petits rectangles les cases à coché
                {
                    Mat imageCut=cutImage.cutImageFunction(source2,(int) rect2.tl().x, (int)rect2.tl().y,rect2.width,rect2.height);
                    Imgcodecs.imwrite(filePath+"imageCoupeeTest2_"+i+".jpg",imageCut);
                   // String folderPath = "/Users/nouhou/Documents/S8_FILES/PFA/ProfResourcesGmail/Resouces1FromGmailRectangle/";
                    //String default_file = folderPath+"jesui2.png";
//        String filename = ((args.length > 0) ? args[0] : default_file);

                   // Mat src = Imgcodecs.imread(default_file, Imgcodecs.IMREAD_GRAYSCALE);
                    //Mat imageSource=cutImage.cutImageFunction(src,469,275,488-469,290-275);
                    //Mat imageSource=src;
                    //HoughLinesRun houghLinesRun =new HoughLinesRun();
                 //   Mat matImageLines=houghLinesRun.run(imageCut);
                   // Imgcodecs.imwrite(filePath+"imageCoupeeTest3_"+i+".jpg",matImageLines);


//                    HighGui.imshow("Detected Lines (in red) - Probabilistic Line Transform", imageCut);
//                    // Wait and Exit
//                    HighGui.waitKey();
//                    System.exit(0);

//                    if (surface[i] < 400) {// this is working but the student should checked in this manner  " v " not in this manner " X " so you have to use the "/Users/nouhou/Desktop/imageChexked.png"
//                        Imgproc.rectangle(resultat, rect2.tl(), rect2.br(), new Scalar(255, 0, 0), 2);//permet de dessiner les rectanlges verst sur l'image
//                        // : on donne l'image=destination, le sommet superier gauche de la matirce rect2[i]=tl()="top left",
//                        // le sommet inferieur droit de la matrice rect2[i]=br()="botttom right" et l'epaisseur de ligne de desssin
//                        //  Imgcodecs.imwrite(filePath+"resultatHereLine67_i_"+i+".jpg", resultat); //c'etait pour voir l'image genere a chque nouvelle iteration
//
//                        Imgproc.putText(resultat, "" + j1, rect2.tl(), 1, 0.5, new Scalar(0, 0, 0));// Scalar(0,0,0) c'est la couleur ?
//                        // Noir: Ici c'est l'ecriture du numero de 0 a 399.
//                        // < Scalar(10,10,10) A inclure ttii pour avoir la marge entre Scalar(0,0,0) et Scalar(10,10,10)
//                        System.out.println("width : " + rect2.width + "height = " + rect2.height + " surface : " + surface[i] + " ration : " + opt);
//                        j1++;
//                    } else {
                        Imgproc.rectangle(resultat2, rect2.tl(), rect2.br(), new Scalar(0, 255, 0), 2);//permet de dessiner les rectanlges verst sur l'image
                        // : on donne l'image=destination, le sommet superier gauche de la matirce rect2[i]=tl()="top left",
                        // le sommet inferieur droit de la matrice rect2[i]=br()="botttom right" et l'epaisseur de ligne de desssin
                        //  Imgcodecs.imwrite(filePath+"resultatHereLine67_i_"+i+".jpg", resultat); //c'etait pour voir l'image genere a chque nouvelle iteration

                        Imgproc.putText(resultat2, "" + j1, rect2.tl(), 1, 0.5, new Scalar(0, 0, 0));// Scalar(0,0,0) c'est la couleur ?
                        // Noir: Ici c'est l'ecriture du numero de 0 a 399.
                        // < Scalar(10,10,10) A inclure ttii pour avoir la marge entre Scalar(0,0,0) et Scalar(10,10,10)
                        System.out.println("rect2.x() :" + rect2.x + "rect2.y :" + rect2.y + "rect2.tl() :" + rect2.tl() + " rect2.br() :" + rect2.br() + " width : " + rect2.width + "height = " + rect2.height + " surface : " + surface[i] + " ration : " + opt);
                        j1++;
                        /*
                    // Nous avons 2 possibilibete pour vsavoir que les cases sont consecutif et apprtiennent a la même question:1. aller avec le nombre case concsecutif oun2. aller avec l'alignement horizontal ou vertical(suivnt  x ou suivant  y)
//                    if ((j1+1)%13==0 && surface[i]==80){// this is working
//                        Imgproc.rectangle(resultat, rect2.tl(), rect2.br(), new Scalar(255,0,0),2);//permet de dessiner les rectanlges verst sur l'image
//                        // : on donne l'image=destination, le sommet superier gauche de la matirce rect2[i]=tl()="top left",
//                        // le sommet inferieur droit de la matrice rect2[i]=br()="botttom right" et l'epaisseur de ligne de desssin
//                        //  Imgcodecs.imwrite(filePath+"resultatHereLine67_i_"+i+".jpg", resultat); //c'etait pour voir l'image genere a chque nouvelle iteration
//
//                        Imgproc.putText(resultat,""+j1, rect2.tl(), 1, 0.5, new Scalar(0,0,0));// Scalar(0,0,0) c'est la couleur ?
//                        // Noir: Ici c'est l'ecriture du numero de 0 a 399.
//                        // < Scalar(10,10,10) A inclure ttii pour avoir la marge entre Scalar(0,0,0) et Scalar(10,10,10)
//                        System.out.println("width : "+rect2.width+"height = "+rect2.height+" surface : "+surface[i]+" ration : "+opt);
//                        j1++;
//                    }else {
//                        Imgproc.rectangle(resultat, rect2.tl(), rect2.br(), new Scalar(0, 255, 0), 2);//permet de dessiner les rectanlges verst sur l'image
//                        // : on donne l'image=destination, le sommet superier gauche de la matirce rect2[i]=tl()="top left",
//                        // le sommet inferieur droit de la matrice rect2[i]=br()="botttom right" et l'epaisseur de ligne de desssin
//                        //  Imgcodecs.imwrite(filePath+"resultatHereLine67_i_"+i+".jpg", resultat); //c'etait pour voir l'image genere a chque nouvelle iteration
//
//                        Imgproc.putText(resultat, "" + j1, rect2.tl(), 1, 0.5, new Scalar(0, 0, 0));// Scalar(0,0,0) c'est la couleur ?
//                        // Noir: Ici c'est l'ecriture du numero de 0 a 399.
//                        // < Scalar(10,10,10) A inclure ttii pour avoir la marge entre Scalar(0,0,0) et Scalar(10,10,10)
//                        System.out.println("rect2.x() :" + rect2.x + "rect2.y :" + rect2.y + "rect2.tl() :" + rect2.tl() + " rect2.br() :" + rect2.br() + " width : " + rect2.width + "height = " + rect2.height + " surface : " + surface[i] + " ration : " + opt);
//                        j1++;

                    }
                    */
                    //}
                }
            }
            System.out.println("contours.size() : "+contours.size());
            System.out.println("contours.size() : "+contoursOfCheckboxes.size());


            Imgcodecs.imwrite(filePath+"resultat.jpg", resultat2);
            Imgcodecs.imwrite(filePath+"destination.jpg", destination);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
