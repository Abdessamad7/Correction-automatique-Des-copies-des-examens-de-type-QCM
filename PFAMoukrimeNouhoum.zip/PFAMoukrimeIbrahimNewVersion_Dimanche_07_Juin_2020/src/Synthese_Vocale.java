import t2s.son.LecteurTexte;
import java.io.*;

public class Synthese_Vocale{
    public static void main(String[] args) {
        LecteurTexte lecteur = new LecteurTexte("bonjour");
        lecteur.playAll();
        lecteur.setTexte("je suis un synthétiseur vocal, qui êtes-vous?");
        lecteur.playAll();
    }
}