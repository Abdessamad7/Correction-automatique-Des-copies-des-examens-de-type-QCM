import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgcodecs.*;
import org.opencv.imgproc.Imgproc;
import org.opencv.core.MatOfPoint;

public class Rectangle2 {
    static CutImage cutImage=new CutImage();


    static public double sqr(double a) {
        return a*a;
    }

    static public double Distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(sqr(y2 - y1) + sqr(x2 - x1));
    }
    public static void correctionFunction() {
        try {
            String filePath="C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\PFAMoukrimeIbrahimNewVersionWindows_Dimanche_19_Juin_2020\\PFAMoukrimeIbrahimNewVersion_Dimanche_07_Juin_2020\\Images\\";
            System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
            Mat source = Imgcodecs.imread(filePath+"image1.jpg", Imgcodecs.IMREAD_ANYCOLOR);
            Mat imageCut=cutImage.cutImageFunction(source,0, 200,900,900-200);
            Imgcodecs.imwrite(filePath+"imageCoupeeTest.jpg",source);
            Mat hierachi=new Mat(source.rows(), source.cols(), source.type());

            Mat resultat = Imgcodecs.imread(filePath+"image1.jpg", Imgcodecs.IMREAD_ANYCOLOR);
            Mat destination = new Mat(source.rows(), source.cols(), source.type());

            Imgproc.cvtColor(source, destination, Imgproc.COLOR_RGB2GRAY);
            Imgcodecs.imwrite(filePath+"image.jpg",destination);

            Imgproc.equalizeHist(destination, destination);
            Imgproc.GaussianBlur(destination, destination, new Size(5, 5), 0, 0, Core.BORDER_DEFAULT);

            source.copyTo(destination);

            Imgproc.cvtColor(destination, destination, Imgproc.COLOR_BGR2GRAY);
            Imgcodecs.imwrite(filePath+"image21.jpg",destination);

            Imgproc.Canny(destination, destination, 100, 100);
            Imgcodecs.imwrite(filePath+"image22.jpg",destination);

            int maxId = 1;
            float opt=(float)(11.6/7.3);
            //MatOfPoint sourceMat =  new MatOfPoint();
            List <MatOfPoint> contours = new ArrayList<MatOfPoint>();
            List <MatOfPoint> contourCherche = new ArrayList<MatOfPoint>();
            List <MatOfPoint> contourCherche2 = new ArrayList<MatOfPoint>();
            List <MatOfPoint> contourCherche3 = new ArrayList<MatOfPoint>();



            List <MatOfPoint> contoursCopy1 = new ArrayList<MatOfPoint>();
            Imgproc.findContours(destination, contours,hierachi,Imgproc.RETR_TREE, Imgproc.CHAIN_APPROX_SIMPLE);
            contoursCopy1=contours;
            System.out.println(hierachi.rows());

            for(int i =0;i<contours.size();i++){
                Rect rect1 = Imgproc.boundingRect(contours.get(i));// on va utiliser lelement i dans contours
                float surface=(float)rect1.width*(float)rect1.height;// surface = longueur*largeur
                if (surface<=8200 && surface>=7000){
                    contourCherche.add(contours.get(i));
                    System.out.println("width : "+rect1.width+"height = "+rect1.height+" surface : "+surface);

                }
            }
            float surface []=new float [contours.size()];
            List arrayListSurface=new ArrayList();
            List arrayListContourTl=new ArrayList();
            List arrayListContourBr=new ArrayList();
            ArrayList<Point> arrayListContourCentre=new ArrayList();
            ArrayList<Point> arrayListContourCentre2=new ArrayList();

            Delta delta=new Delta();
            int j1=0;
            for (int i=0;i<contours.size();i++)
            {
                Rect rect = Imgproc.boundingRect(contours.get(i));
                surface[i]=(float)rect.width*(float)rect.height;

                // if(surface[i]<=8100 && surface[i]>=7100)

                if(surface[i]>=3550 && surface[i]<=3800)
                {
                    int j=0;
                    for ( j=0;j<=arrayListSurface.size();j++){
                        if(!contourCherche2.contains(contours.get(i))){
                            if (!arrayListContourTl.contains(rect.tl())){
                                if(!arrayListContourBr.contains(rect.br())){
                                    contourCherche2.add(contours.get(i));//n'est pas vide
                                    arrayListSurface.add((float)rect.width*(float)rect.height);
                                    arrayListContourTl.add(rect.tl());
                                    arrayListContourTl.add(rect.br());
                                    //Imgproc.rectangle(resultat, rect.tl(), rect.br(), new Scalar(0,255,0),1/5);
                                    System.out.println("les contours cherches2 "+contourCherche2.get(j).toList().toString());
                                    Point centrePoint=new Point(rect.tl().x+rect.width/2,rect.tl().y+rect.height/2);
                                    System.out.println( "etape j "+ j +": centre : "+ centrePoint.toString());
                                    //Imgproc.putText(resultat,"*", centrePoint, 1, 0.5, new Scalar(0,255,0));
                                    arrayListContourCentre.add(centrePoint);


                                }
                            }
                        }

                    }
                    // ceci permet d'ordonner la liste contourCherche2 de haut en bas et de la droite vers la gauche
                    //sort by y coordinates using the topleft point of every contour's bounding box
                    Collections.sort(contourCherche2, new Comparator<MatOfPoint>() {
                        @Override
                        public int compare(MatOfPoint o1, MatOfPoint o2) {
                            Rect rect1 = Imgproc.boundingRect(o1);
                            Rect rect2 = Imgproc.boundingRect(o2);
                            int result = Double.compare(rect1.tl().y, rect2.tl().y);
                            return result;
                        }
                    }.reversed() );


//sort by x coordinates
                    Collections.sort(contourCherche2, new Comparator<MatOfPoint>() {
                        @Override
                        public int compare(MatOfPoint o1, MatOfPoint o2) {
                            Rect rect1 = Imgproc.boundingRect(o1);
                            Rect rect2 = Imgproc.boundingRect(o2);
                            int result = 0;
                            double total = rect1.tl().y/rect2.tl().y;
                            if (total>=0.9 && total<=1.4 ){
                                result = Double.compare( rect2.tl().x,rect1.tl().x);// c'est inverser
                            }
                            return result;
                        }
                    });

                    for ( Point point:arrayListContourCentre) {
                        if ((delta.Distance(new Point(rect.tl().x + rect.width / 2, rect.tl().y + rect.height / 2), point) > 10)) {
                            if (!arrayListContourCentre2.contains(new Point(rect.tl().x + rect.width / 2, rect.tl().y + rect.height / 2)))
                                if (!contourCherche3.contains(contours.get(i))) {

                                    arrayListContourCentre2.add(new Point(rect.tl().x + rect.width / 2, rect.tl().y + rect.height / 2));
                                    contourCherche3.add(contours.get(i));//n'est pas vide


                                }

                        }
                    }

                    System.out.println( " surface lenght at i : "+arrayListSurface.size());
                    System.out.println( " contours Chercher 2 at i : "+contourCherche2.size());
                    System.out.println( " contours centre all : "+arrayListContourCentre.toString());
                    System.out.println( " contours centre 2 all : "+arrayListContourCentre2.toString());
                    System.out.println( " contours Chercher 3 all : "+contourCherche3.size());

                    System.out.println( j1 +":" + "width : "+rect.width+"height = "+rect.height+" surface : "+surface[i]+" ration : "+opt);
                    j1++;
                }
            }
            System.out.println("size de c2 est "+contourCherche2.size());
            for (int l=0 ;l<contourCherche2.size();l++){// voir
                //if (!(l==contourCherche2.size()-1)){// voir pourquoi en suivant les resultats line per line
                Rect rectNew = Imgproc.boundingRect(contourCherche2.get(l));

                Imgproc.rectangle(resultat, rectNew.tl(), rectNew.br(), new Scalar(0,255,0),1/5);
                Mat imageCutNew=cutImage.cutImageFunction(source,(int) rectNew.tl().x, (int)rectNew.tl().y,rectNew.width,rectNew.height);
                Imgcodecs.imwrite(filePath+"imageCoupeeTest2_"+l+".jpg",imageCutNew);

                // HoughLinesRun houghLinesRun =new HoughLinesRun();
                //  Mat matImageLines=houghLinesRun.run(imageCutNew);
                //  Imgcodecs.imwrite(filePath+"imageCoupeeHou_"+l+".jpg",matImageLines);
                //  }

            }

            System.out.println("Le nombre de fois qu'on a dessine les contours : "+j1);
            //contourCherche2.remove(9);// le probleme c'est que les 2 derniers elements de contourCherche2 sont approximativemnt les memes (on a supprimer un: le dernier)
            int[][] papierAnswerArray = new int[3][3];
            for (int l=0 ;l<contourCherche2.size();l++){// voir
                // voir pourquoi en suivant les resultats line per line// le probleme c'est que les 2 derniers elements de contourCherche2 sont approximativemnt les memes
                Rect rectNew = Imgproc.boundingRect(contourCherche2.get(8-l));//pour commencer de haut en bas et de la gauche vers la droite . car le contourCherche2 est remplie de bas en haut
                // Mat destinationNew = new Mat(source.rows(), source.cols(), source.type());
                Mat imageCutNew=cutImage.cutImageFunction(source,(int) rectNew.tl().x, (int)rectNew.tl().y,rectNew.width,rectNew.height);
                Imgcodecs.imwrite(filePath+"imageCoupeeTest2_"+l+".jpg",imageCutNew);
                getPixelOfImageFunction getPixelObject=new getPixelOfImageFunction();
                double valeurMoyennePixel=getPixelObject.getPixelSum(imageCutNew);
                System.out.println("la moyenne en pixel l'image : "+l +" est "+valeurMoyennePixel);
                Imgproc.putText(resultat, "" + l, rectNew.tl(), 1, 0.5, new Scalar(0, 0, 0));// Scalar(0,0,0) c'est la couleur ?
                //Imgproc.putText(resultat, "" + (int) valeurMoyennePixel, rectNew.tl(), 1, 0.5, new Scalar(0, 0, 0));// Scalar(0,0,0) c'est la couleur ?
                int cocher=0;
                int nonCocher=0;
                int seuilPixel=80;
                if (valeurMoyennePixel<=seuilPixel){
                    System.out.println("Cocher");
                    cocher=1;
                }else {
                    System.out.println("NonCocher");
                    cocher=0;
                }
                papierAnswerArray[(int)(l/3)][l%3]=cocher;
            }
            for (int i=0;i<3;i++){
                for (int j=0;j<3;j++){
                    System.out.print(papierAnswerArray[i][j]+"  ");
                }
                System.out.println("  ");
            }
            int[][] matriceC = {{0, 1, 0}, {0, 1, 0}, {0, 1, 0}};
            Comparer2Matrices comparer2Matrices=new Comparer2Matrices();
            float noteRecu=comparer2Matrices.compare2MatricesFunction(papierAnswerArray,matriceC);
            System.out.println("Dans la classe Rectangle2 : La note recu par l'etudiant E est : "+noteRecu);




            Imgcodecs.imwrite(filePath+"resultat.jpg", resultat);
            Imgcodecs.imwrite(filePath+"destination.jpg", destination);

        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
        }
    }
    public static void main(String[] args) {
        try {
            correctionFunction();
        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
        }
    }
    public static class Delta {

        static public double sqr(double a) {
            return a*a;
        }

        static public double Distance(Point p1,Point p2) {
            return Math.sqrt(sqr(p2.y - p1.y) + sqr(p2.x - p1.x));
        }

        public static void main(String[] args) {
            System.out.print("Calcul la distance entre deux points (0,0)-(10,10): " +Distance(new Point(0,0), new Point(10,10))+"\n");
            System.out.print("Calcul la distance entre deux points (2,2)-(10,10): "+Distance(new Point(2,2), new Point(10,10))+"\n");
        }
    }
}
