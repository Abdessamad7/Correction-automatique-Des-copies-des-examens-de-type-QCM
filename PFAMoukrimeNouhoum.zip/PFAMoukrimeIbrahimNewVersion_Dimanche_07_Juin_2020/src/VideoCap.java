import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.videoio.VideoCapture;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class VideoCap {
    public static void main (String args[]){
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        VideoCapture camera = new VideoCapture(0);
        System.out.println("Welcome to OpenCV " + Core.VERSION);
        JButton capturerImage=new JButton("Capturer");



        if(!camera.isOpened()){
            System.out.println("Error");
        }
        else {
            //Mat frame = new Mat();
           // VideoCapture camera = new VideoCapture("C:/Users/SAAD/Desktop/motion.mp4");
            JFrame jframe = new JFrame("Title");
            jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JLabel vidpanel = new JLabel();
            capturerImage.setBounds(0, 0, 18, 39);

            jframe.add(capturerImage);
            jframe.add(vidpanel);
            vidpanel.setBounds(18,39,130,130);
            jframe.setSize(420, 530);
            jframe.setVisible(true);
            Mat frame = new Mat();
            camera.read(frame);
            int i=0;

            while(true){
                if (camera.read(frame)){
                    ImageIcon image = new ImageIcon(new JPanelOpenCV().MatToBufferedImage(frame));
                    vidpanel.setIcon(image);
                    vidpanel.repaint();
                    capturerImage.addActionListener(new ActionListener() {

                        @Override
                        public void actionPerformed(ActionEvent e) {
                            System.out.println("Frame Obtained");
                            return;
                        }

                    });
                    System.out.println("Captured Frame Width " +
                            frame.width() + " Height " + frame.height());
                    Imgcodecs.imwrite("/Users/nouhou/Documents/S8_FILES/MiniProjects/Crypto/PFAMoukrimeIbrahim/Images/image1.jpg", frame);
                    System.out.println("OK");
                  //  break; arrete sur la vidoe sur la derniere frame = photo


                }
            }


        }

       // camera.release();
    }
}  