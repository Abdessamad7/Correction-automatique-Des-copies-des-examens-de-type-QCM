//import static org.opencv.highgui.Highgui.imread;
//import static org.opencv.highgui.Highgui.imwrite;
import static org.opencv.imgproc.Imgproc.COLOR_BGR2GRAY;
import static org.opencv.imgproc.Imgproc.cvtColor;


import java.awt.*;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.excel.lib.util.Xls_Reader;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;


/**
 * Recognize text from image
 *
 * @author tramvm@gmail.com
 *
 */
public class RecognizeText {
    private  static Mat origin;

    // Source path content images
    static String SRC_PATH = "C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\PFAMoukrimeIbrahimNewVersionWindows_Dimanche_19_Juin_2020\\PFAMoukrimeIbrahimNewVersion_Dimanche_07_Juin_2020\\Images\\ImagesNewFolder\\";
    static String TESS_DATA = "C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\lesJars\\Tess4J-3.4.8-src\\Tess4J\\tessdata";
    static Tesseract tesseract = new Tesseract();    // Create tess obj

    // Load OPENCV
    static {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        tesseract.setDatapath(TESS_DATA);
    }


     Map<String,String> extractTextFromImage(Mat inputMat, int rectangleNomX, int rectangleNomY, int rectangleNomWidth, int rectangleNomHeight, int rectangleIdX, int rectangleIdY, int rectangleIdWidth, int rectangleIdHeight) {
        String resultNomEtudiant = "";
        String resultIdEtudiant = "";

        String resultArray[];

        Mat gray = new Mat();

        cvtColor(inputMat, gray, COLOR_BGR2GRAY);
         Map<String,String> donneeLues=new HashMap<>();

        try {
            // Recognize text with OCR
            Rectangle rectangleNomEtudiant=new Rectangle(rectangleNomX, rectangleNomY, rectangleNomWidth, rectangleNomHeight);// ceci met le premier angle superieur gauche du rectangle a (38,137)
            // et met alors la largeur et la hauteur. Pour connaitre il faut faire un zoom avant ou arriere avec la souris
            // et alors utiliser le curseur de mesure de l'image
            Rectangle rectangleIdEtudiant=new Rectangle(rectangleIdX,rectangleIdY,rectangleIdWidth,rectangleIdHeight);
            resultNomEtudiant = tesseract.doOCR(new File(SRC_PATH + "image1.jpg"),rectangleNomEtudiant);
            resultIdEtudiant = tesseract.doOCR(new File(SRC_PATH + "image1.jpg"),rectangleIdEtudiant);
            donneeLues.put("IdEtudiant",resultIdEtudiant);
            donneeLues.put("NomEtudiant", resultNomEtudiant);
            System.out.println(donneeLues.toString());

        } catch (TesseractException e) {
            e.printStackTrace();
        }

        return donneeLues;
    }

    public static void main(String[] args) {
        System.out.println("Start recognize text from image");
        long start = System.currentTimeMillis();

        origin = Imgcodecs.imread(SRC_PATH+"image1.jpg", Imgcodecs.IMREAD_ANYCOLOR);// transforme l'image en matrice

//
        Map<String,String> resultMap = new RecognizeText().extractTextFromImage(origin,250,240,865-250,339-240,250,240+100,865-250,339-240);

        Xls_Reader xls_reader2=new Xls_Reader("C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\PFAMoukrimeIbrahimNewVersionWindows_Dimanche_19_Juin_2020\\PFAMoukrimeIbrahimNewVersion_Dimanche_07_Juin_2020\\src\\PfaExcelSheets.xlsx");

        String sheetName="Sheet2";
        if (!xls_reader2.isSheetExist(sheetName)){
            xls_reader2.addSheet(sheetName);
        }

        String columnIdToAdd ="Identifiant etudiant";
        String columnNomEtudiantToAdd ="Prenoms et noms";
        String columnNoteToAdd ="Notes";
        String columnMoyenneToAdd ="Moyenne de la classe";
// To do just the first time of the sheet
//        Boolean isColumnIdAdded=xls_reader2.addColumn(sheetName, columnIdToAdd);// NB: you have to close the sheet first
//        Boolean isColumnNomAdded=xls_reader2.addColumn(sheetName, columnNomEtudiantToAdd);// NB: you have to close the sheet first
//        Boolean isColumnNoteAdded=xls_reader2.addColumn(sheetName, columnNoteToAdd);// NB: you have to close the sheet first
//        Boolean isColumnMoyenneAdded=xls_reader2.addColumn(sheetName, columnMoyenneToAdd);// NB: you have to close the sheet first
//
//        System.out.println("Column "+ columnIdToAdd +" is added : " + isColumnNomAdded );

        int rowNumber=xls_reader2.getRowCount(sheetName);
        Boolean isDataIdAdded =xls_reader2.setCellData(sheetName, columnIdToAdd,rowNumber+1,resultMap.get("IdEtudiant"));
        Boolean isDataNomAdded =xls_reader2.setCellData(sheetName, columnNomEtudiantToAdd,rowNumber+1,resultMap.get("NomEtudiant"));
//        Boolean isDataNoteAdded =xls_reader2.setCellData(sheetName, columnNoteToAdd,rowNumber+1,resultMap.get("IdEtudiant"));
//        Boolean isDataMoyenneAdded =xls_reader2.setCellData(sheetName, columnMoyenneToAdd,rowNumber+1,resultMap.get("IdEtudiant"));


        System.out.println("Data added at column "+ columnIdToAdd +" and line : "+(rowNumber+1) +" is "+isDataNomAdded);

        System.out.println(resultMap.get("IdEtudiant"));
        System.out.println(resultMap.get("NomEtudiant"));
        System.out.println("Time");
        System.out.println(System.currentTimeMillis() - start);
        System.out.println("Done");
    }
}