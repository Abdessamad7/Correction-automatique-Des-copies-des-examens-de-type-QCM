import com.excel.lib.util.Xls_Reader;

public class testXlsReaderClass {
    public static void main(String [] args){
        Xls_Reader xls_reader=new Xls_Reader("/Users/nouhou/Documents/S8_FILES/MiniProjects/Crypto/PFAMoukrimeIbrahim/src/SampleExcel.xlsx");
        String sheetName="login";
        String data1 =xls_reader.getCellData(sheetName,0,2);
        System.out.println(data1);
        int rowNumber=xls_reader.getRowCount(sheetName);

        System.out.println("number of rows in this sheet is : "+rowNumber);
        //Boolean isColumnAdded=xls_reader.addColumn(sheetName,"status2");// NB: you have to close the sheet first
        // System.out.println("Column added : " + isColumnAdded );

        if (!xls_reader.isSheetExist("Registration")){
            xls_reader.addSheet("Registration");
        }
        String columsToAddData="status";
        String dataToAddInCell="passAtLastRowUded";
//        Boolean isDataAdded =xls_reader.setCellData(sheetName,columsToAddData,rowNumber,dataToAddInCell);
//        System.out.println("Data added at column "+columsToAddData+" and line : "+rowNumber+"is "+isDataAdded);
        String columsToGetData="username";

//        for(int i=1;i<=rowNumber;i++){
//            String dataFromCell3=xls_reader.getCellData(sheetName,columsToGetData,i);
//            System.out.println(dataFromCell3);
//        }
        //NB: collumns start with 0,1,2,... BUT rows start with 1,2,3,...

        int columnNumber=xls_reader.getColumnCount(sheetName);
        System.out.println("There are "+columnNumber+" columns   ");

        String columnToRemove="status2";
        int columnToRemoveOrder=columnNumber-1;
//        Boolean isCollumnRemoved =xls_reader.removeColumn(sheetName,columnToRemoveOrder);
//        System.out.println("Collum removed is "+columnToRemove+" at order : "+columnToRemoveOrder+" is "+isCollumnRemoved);


//        System.out.println(xls_reader.setCellData("Registration","phonenumber",3,"123"));
//
//        System.out.println(xls_reader.getCellData("Registration",columsToGetData,2));



    }

}
