
//    // Variables declaration - do not modify//GEN-BEGIN:variables
//    private javax.swing.JButton jButton1;
//    private javax.swing.JLabel jLabel1;
//    private javax.swing.JLabel jLabel2;
//    private javax.swing.JPanel jPanel1;
//    private javax.swing.JScrollPane jScrollPane1;
//    private javax.swing.JScrollPane jScrollPane2;
//    private javax.swing.JTextArea txtArea;
//    private javax.swing.JTextArea txtٍٍٍShow;
//
//import javax.swing.*;
//import java.io.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.util.ArrayList;
//
//import com.sun.speech.freetts.*;
//
//public class TextToSpeech extends JFrame {
//    private JTextArea textArea;
//    private JButton speakButton;
//    private JPanel mainPanel;
//    private JLabel textShowLabel;
//    private final static String VOICNAME = "kevin16";
//
//    private static final String VOICENAME="kevin8k";
//    String arabicLetters;
//    String englishLetters;
//    ArrayList<String> englistLettersArray = new ArrayList<>();
//
//    public TextToSpeech() {
//        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        this.setContentPane(mainPanel);
//        this.pack();
//        arabicLetters = "ءاأبتثجحخدذرزسشصضطظعغفقكلمنهويةئه";
//        englishLetters = new StringBuilder("aaaywhnmlkkfgaztdssszrzdahgstbaaa").reverse().toString();
//
//
//
//
//        speakButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//
//
//                if (textArea.getText().isEmpty() == false) {
//                    englistLettersArray.clear();
//                    String phase = textArea.getText();
//                    System.out.println("line 50"+phase.toString());
//                    String[] splited = phase.split("\\s+");
//                    System.out.println("line 51"+splited.toString());
//                    for (String splited1 : splited) {
//                        System.out.println("line 54"+splited1.toString());
//
//                        for (int x = 0; x < splited1.length(); x++) {
//                            String lett = String.valueOf(splited1.charAt(x));
//                            if (arabicLetters.contains(lett)) {
//                                int index = arabicLetters.indexOf(lett);
//                                String engLet = String.valueOf(englishLetters.charAt(index));
//                                englistLettersArray.add(engLet);
//                            }
//                        }
//                        englistLettersArray.add("");
//                    }
//                    String transWord = "";
//                    for (int x = 0; x < englistLettersArray.size(); x++) {
//                        String letter = englistLettersArray.get(x).toString();
//                        if (letter.equals("")) {
//                            transWord = transWord + " " + letter;
//                        } else {
//                            transWord = transWord + letter;
//                        }
//
//                    }
//                    System.out.println("line 73"+transWord.toString());
//
//                    Do(transWord);
////                } else {
////                    JOptionPane.showMessageDialog(this, "Write text first", "Error Message", JOptionPane.ERROR_MESSAGE);
////                    textArea.requestFocus();
//                }
//
//            }
//        });
//    }
//
//
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(TextToSpeech.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(TextToSpeech.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(TextToSpeech.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(TextToSpeech.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        JFrame jFrame=new TextToSpeech();
//        jFrame.setVisible(true);
//    }
//
//
//
//    private void Do(String transWord) {
//
//        System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");
//
//        Voice voice;
//        VoiceManager vm = VoiceManager.getInstance();
//        voice = vm.getVoice(VOICNAME);
//
//        if (voice != null) {
//        voice.allocate();
//        voice.setRate(170);
//        voice.setPitch(100);
//        try {
//            StringBuffer res = new StringBuffer();
//
//            String[] strArr = transWord.split(" ");
//            System.out.println("line 134"+strArr.toString());
//
//            for (String str : strArr) {
//                char[] stringArray = str.trim().toCharArray();
//                stringArray[0] = Character.toUpperCase(stringArray[0]);
//                str = new String(stringArray);
//
//                res.append(str).append(" ");
//            }
//            textShowLabel.setText("" + res.toString().trim());
//            System.out.println("line 144"+res.toString());
//
//            voice.speak(res.toString());
//        } catch (Exception e) {
//        }
//        } else {
//            throw new IllegalStateException("Cannot find voice: kevin16");
//        }
//
//    }
//}



////////////////////copy under ///

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import com.sun.speech.freetts.*;

public class TextToSpeech extends JFrame {
    private JTextArea textArea;
    private JButton speakButton;
    private JPanel mainPanel;

    private static final String VOICENAME="kevin8k";
    public TextToSpeech() {

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(mainPanel);
        this.pack();

        speakButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                TextTSpeech(textArea.getText());
            }
        });
    }

    public static void main(String[] args){
        JFrame jFrame=new TextToSpeech();
        jFrame.setVisible(true);
    }

    public void TextTSpeech(String words) {
        System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");
        Voice voice;
        voice = VoiceManager.getInstance().getVoice("kevin16");
        if (voice != null) {
            voice.allocate();// Allocating Voice
            try {
                voice.setRate(190);// Setting the rate of the voice
                voice.setPitch(150);// Setting the Pitch of the voice
                voice.setVolume(3);// Setting the volume of the voice
                voice.speak(words);// Calling speak() method

            } catch (Exception e1) {
                e1.printStackTrace();
            }

        } else {
            throw new IllegalStateException("Cannot find voice: kevin16");
        }
    }
}
