import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Rect;
import org.opencv.imgcodecs.Imgcodecs;

public class CutImage {
    private static int start_x = 0;
    private static  int start_y = 0;
    private static int width = 100;
    private static int height = 100;

    public static void main(String[] args) {
        try {
            System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
            String folderPath = "C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\PFAMoukrimeIbrahimNewVersionWindows_Dimanche_19_Juin_2020\\PFAMoukrimeIbrahimNewVersion_Dimanche_07_Juin_2020\\Images\\ImagesNewFolder\\";
            String filePath = folderPath+"image1.jpg";

            Mat imageCoupee=cutImageFunction(filePath,250,240,865-250,339-240);
            Imgcodecs.imwrite(folderPath+"imageCoupeeTest.jpg",imageCoupee);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    public static Mat cutImageFunction(String sourceImagePath, int cropStart_X, int cropStart_Y, int cropWidth, int cropHeight){

        Rect rectCrop = new Rect(cropStart_X, cropStart_Y, cropWidth, cropHeight);
        // this the where the ressources are
        Mat original_image = Imgcodecs.imread(sourceImagePath, Imgcodecs.IMREAD_ANYCOLOR);// transforme l'image en matrice
        // generate matrix of the interested region, from original_image
        Mat image_roi = new Mat(original_image, rectCrop);
        return image_roi;
    }

    public static Mat cutImageFunction(Mat sourceImageMat, int cropStart_X, int cropStart_Y, int cropWidth, int cropHeight){

        Rect rectCrop = new Rect(cropStart_X, cropStart_Y, cropWidth, cropHeight);
        // generate matrix of the interested region, from original_image
        Mat image_roi = new Mat(sourceImageMat, rectCrop);
        return image_roi;
    }
}
