import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.excel.lib.util.Xls_Reader;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;
import java.awt.Color;
import javax.imageio.ImageIO;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.*;

public class VideoClass extends JFrame {
    static Voice e = new Voice();
    public String path;
    private XSSFRow row = null;
    private XSSFCell cell = null;
    public FileInputStream fis = null;
    public FileOutputStream fileOut = null;
    private XSSFWorkbook workbook = null;
    private XSSFSheet sheet = null;
    private  static Mat origin;
    static Xls_Reader xls_reader2=new Xls_Reader("C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\PFAMoukrimeIbrahimNewVersionWindows_Dimanche_19_Juin_2020\\PFAMoukrimeIbrahimNewVersion_Dimanche_07_Juin_2020\\src\\PfaExcelSheets.xlsx");
    static String sheetName="Sheet2";

    static int rowNumber=xls_reader2.getRowCount(sheetName);
    static String columnIdToAdd ="Identifiant etudiant";
    static String columnNomEtudiantToAdd ="Prenoms et noms";
    static String columnNoteToAdd ="Notes";
    static String columnMoyenneToAdd ="Moyenne de la classe";
    // Source path content images
    static String SRC_PATH = "C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\PFAMoukrimeIbrahimNewVersionWindows_Dimanche_19_Juin_2020\\PFAMoukrimeIbrahimNewVersion_Dimanche_07_Juin_2020\\Images\\ImagesNewFolder\\";
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    JButton Start;
    JButton b1;
    JButton b2;
    JButton b3;
    JButton b4;
    JTextField textFieldIpChemin;
    JCheckBox checkBoxTelephoneConnecte;
    JCheckBox checkBoxNombreCopieRestant;
    JPanel video;
    private Tracking myThread = null;
    VideoCapture webSource = null;
    Mat frame = new Mat();
    MatOfByte mem = new MatOfByte();

    static CutImage cutImage=new CutImage();
    static int  nombreCopieRestant=3;

    public boolean setCellStyle(String sheetName, String colName, int rowNum, String styleColorString ) {
        try {
            path="C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\PFAMoukrimeIbrahimNewVersionWindows_Dimanche_19_Juin_2020\\PFAMoukrimeIbrahimNewVersion_Dimanche_07_Juin_2020\\src\\PfaExcelSheets.xlsx";
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);

            if (rowNum <= 0) return false;

            int index = workbook.getSheetIndex(sheetName);
            int colNum = -1;
            if (index == -1) return false;

            sheet = workbook.getSheetAt(index);

            row = sheet.getRow(0);
            for (int i = 0; i < row.getLastCellNum(); i++) {
                // System.out.println(row.getCell(i).getStringCellValue().trim());
                if (row.getCell(i).getStringCellValue().trim().equals(colName))
                    colNum = i;
            }
            if (colNum == -1)
                return false;

            sheet.autoSizeColumn(colNum);
            row = sheet.getRow(rowNum - 1);
            if (row == null)
                row = sheet.createRow(rowNum - 1);

            cell = row.getCell(colNum);
            if (cell == null)
                cell = row.createCell(colNum);
            // cell style
            CellStyle cs = workbook.createCellStyle();
            // Setting Background color
            if (styleColorString=="green"){
                cs.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
            } else  cs.setFillBackgroundColor(IndexedColors.RED.getIndex());

            cs.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            //cs.setWrapText(true);
            cell.setCellStyle(cs);
//			cell.setCellValue(data);

            fileOut = new FileOutputStream(path);

            workbook.write(fileOut);

            fileOut.close();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
    public static void correctionFunction() {
        try {
            String filePath="C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\PFAMoukrimeIbrahimNewVersionWindows_Dimanche_19_Juin_2020\\PFAMoukrimeIbrahimNewVersion_Dimanche_07_Juin_2020\\Images\\";
            System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
            Mat source = Imgcodecs.imread(filePath+"image1.jpg", Imgcodecs.IMREAD_ANYCOLOR);
            Mat imageCut=cutImage.cutImageFunction(source,0, 200,900,900-200);
            Imgcodecs.imwrite(filePath+"imageCoupeeTest.jpg",source);
            Mat hierachi=new Mat(source.rows(), source.cols(), source.type());

            Mat resultat = Imgcodecs.imread(filePath+"image1.jpg", Imgcodecs.IMREAD_ANYCOLOR);
            Mat destination = new Mat(source.rows(), source.cols(), source.type());

            Imgproc.cvtColor(source, destination, Imgproc.COLOR_RGB2GRAY);
            Imgcodecs.imwrite(filePath+"image.jpg",destination);

            Imgproc.equalizeHist(destination, destination);
            Imgproc.GaussianBlur(destination, destination, new Size(5, 5), 0, 0, Core.BORDER_DEFAULT);

            source.copyTo(destination);

            Imgproc.cvtColor(destination, destination, Imgproc.COLOR_BGR2GRAY);
            Imgcodecs.imwrite(filePath+"image21.jpg",destination);

            Imgproc.Canny(destination, destination, 100, 100);
            Imgcodecs.imwrite(filePath+"image22.jpg",destination);

            int maxId = 1;
            float opt=(float)(11.6/7.3);
            //MatOfPoint sourceMat =  new MatOfPoint();
            List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
            List <MatOfPoint> contourCherche = new ArrayList<MatOfPoint>();
            List <MatOfPoint> contourCherche2 = new ArrayList<MatOfPoint>();
            List <MatOfPoint> contourCherche3 = new ArrayList<MatOfPoint>();



            List <MatOfPoint> contoursCopy1 = new ArrayList<MatOfPoint>();
            Imgproc.findContours(destination, contours,hierachi,Imgproc.RETR_TREE, Imgproc.CHAIN_APPROX_SIMPLE);
            contoursCopy1=contours;
            System.out.println(hierachi.rows());

            for(int i =0;i<contours.size();i++){
                Rect rect1 = Imgproc.boundingRect(contours.get(i));// on va utiliser lelement i dans contours
                float surface=(float)rect1.width*(float)rect1.height;// surface = longueur*largeur
                if (surface<=8200 && surface>=7000){
                    contourCherche.add(contours.get(i));
                    System.out.println("width : "+rect1.width+"height = "+rect1.height+" surface : "+surface);

                }
            }
            float surface []=new float [contours.size()];
            List arrayListSurface=new ArrayList();
            List arrayListContourTl=new ArrayList();
            List arrayListContourBr=new ArrayList();
            ArrayList<Point> arrayListContourCentre=new ArrayList();
            ArrayList<Point> arrayListContourCentre2=new ArrayList();

            Rectangle2.Delta delta=new Rectangle2.Delta();
            int j1=0;
            for (int i=0;i<contours.size();i++)
            {
                Rect rect = Imgproc.boundingRect(contours.get(i));
                surface[i]=(float)rect.width*(float)rect.height;

                // if(surface[i]<=8100 && surface[i]>=7100)

                if(surface[i]>=3550 && surface[i]<=3800)
                {
                    int j=0;
                    for ( j=0;j<=arrayListSurface.size();j++){
                        if(!contourCherche2.contains(contours.get(i))){
                            if (!arrayListContourTl.contains(rect.tl())){
                                if(!arrayListContourBr.contains(rect.br())){
                                    contourCherche2.add(contours.get(i));//n'est pas vide
                                    arrayListSurface.add((float)rect.width*(float)rect.height);
                                    arrayListContourTl.add(rect.tl());
                                    arrayListContourTl.add(rect.br());
                                    //Imgproc.rectangle(resultat, rect.tl(), rect.br(), new Scalar(0,255,0),1/5);
                                    System.out.println("les contours cherches2 "+contourCherche2.get(j).toList().toString());
                                    Point centrePoint=new Point(rect.tl().x+rect.width/2,rect.tl().y+rect.height/2);
                                    System.out.println( "etape j "+ j +": centre : "+ centrePoint.toString());
                                    //Imgproc.putText(resultat,"*", centrePoint, 1, 0.5, new Scalar(0,255,0));
                                    arrayListContourCentre.add(centrePoint);


                                }
                            }
                        }

                    }
                    // ceci permet d'ordonner la liste contourCherche2 de haut en bas et de la droite vers la gauche
                    //sort by y coordinates using the topleft point of every contour's bounding box
                    Collections.sort(contourCherche2, new Comparator<MatOfPoint>() {
                        @Override
                        public int compare(MatOfPoint o1, MatOfPoint o2) {
                            Rect rect1 = Imgproc.boundingRect(o1);
                            Rect rect2 = Imgproc.boundingRect(o2);
                            int result = Double.compare(rect1.tl().y, rect2.tl().y);
                            return result;
                        }
                    }.reversed() );


//sort by x coordinates
                    Collections.sort(contourCherche2, new Comparator<MatOfPoint>() {
                        @Override
                        public int compare(MatOfPoint o1, MatOfPoint o2) {
                            Rect rect1 = Imgproc.boundingRect(o1);
                            Rect rect2 = Imgproc.boundingRect(o2);
                            int result = 0;
                            double total = rect1.tl().y/rect2.tl().y;
                            if (total>=0.9 && total<=1.4 ){
                                result = Double.compare( rect2.tl().x,rect1.tl().x);// c'est inverser
                            }
                            return result;
                        }
                    });

                    for ( Point point:arrayListContourCentre) {
                        if ((delta.Distance(new Point(rect.tl().x + rect.width / 2, rect.tl().y + rect.height / 2), point) > 10)) {
                            if (!arrayListContourCentre2.contains(new Point(rect.tl().x + rect.width / 2, rect.tl().y + rect.height / 2)))
                                if (!contourCherche3.contains(contours.get(i))) {

                                    arrayListContourCentre2.add(new Point(rect.tl().x + rect.width / 2, rect.tl().y + rect.height / 2));
                                    contourCherche3.add(contours.get(i));//n'est pas vide


                                }

                        }
                    }

                    System.out.println( " surface lenght at i : "+arrayListSurface.size());
                    System.out.println( " contours Chercher 2 at i : "+contourCherche2.size());
                    System.out.println( " contours centre all : "+arrayListContourCentre.toString());
                    System.out.println( " contours centre 2 all : "+arrayListContourCentre2.toString());
                    System.out.println( " contours Chercher 3 all : "+contourCherche3.size());

                    System.out.println( j1 +":" + "width : "+rect.width+"height = "+rect.height+" surface : "+surface[i]+" ration : "+opt);
                    j1++;
                }
            }
            System.out.println("size de c2 est "+contourCherche2.size());
            for (int l=0 ;l<contourCherche2.size();l++){// voir
                //if (!(l==contourCherche2.size()-1)){// voir pourquoi en suivant les resultats line per line
                Rect rectNew = Imgproc.boundingRect(contourCherche2.get(l));

                Imgproc.rectangle(resultat, rectNew.tl(), rectNew.br(), new Scalar(0,255,0),1/5);
                Mat imageCutNew=cutImage.cutImageFunction(source,(int) rectNew.tl().x, (int)rectNew.tl().y,rectNew.width,rectNew.height);
                Imgcodecs.imwrite(filePath+"imageCoupeeTest2_"+l+".jpg",imageCutNew);



            }

            System.out.println("Le nombre de fois qu'on a dessine les contours : "+j1);
            //contourCherche2.remove(9);// le probleme c'est que les 2 derniers elements de contourCherche2 sont approximativemnt les memes (on a supprimer un: le dernier)
            int[][] papierAnswerArray = new int[3][3];
            for (int l=0 ;l<contourCherche2.size();l++){// voir
                // voir pourquoi en suivant les resultats line per line// le probleme c'est que les 2 derniers elements de contourCherche2 sont approximativemnt les memes
                Rect rectNew = Imgproc.boundingRect(contourCherche2.get(8-l));//pour commencer de haut en bas et de la gauche vers la droite . car le contourCherche2 est remplie de bas en haut
                // Mat destinationNew = new Mat(source.rows(), source.cols(), source.type());
                Mat imageCutNew=cutImage.cutImageFunction(source,(int) rectNew.tl().x, (int)rectNew.tl().y,rectNew.width,rectNew.height);
                Imgcodecs.imwrite(filePath+"imageCoupeeTest2_"+l+".jpg",imageCutNew);
                getPixelOfImageFunction getPixelObject=new getPixelOfImageFunction();
                double valeurMoyennePixel=getPixelObject.getPixelSum(imageCutNew);
                System.out.println("la moyenne en pixel l'image : "+l +" est "+valeurMoyennePixel);
                Imgproc.putText(resultat, "" + l, rectNew.tl(), 1, 0.5, new Scalar(0, 0, 0));// Scalar(0,0,0) c'est la couleur ?
                //Imgproc.putText(resultat, "" + (int) valeurMoyennePixel, rectNew.tl(), 1, 0.5, new Scalar(0, 0, 0));// Scalar(0,0,0) c'est la couleur ?
                int cocher=0;
                int nonCocher=0;
                int seuilPixel=80;
                if (valeurMoyennePixel<=seuilPixel){
                    System.out.println("Cocher");
                    cocher=1;
                }else {
                    System.out.println("NonCocher");
                    cocher=0;
                }
                papierAnswerArray[(int)(l/3)][l%3]=cocher;
            }
            for (int i=0;i<3;i++){
                for (int j=0;j<3;j++){
                    System.out.print(papierAnswerArray[i][j]+"  ");
                }
                System.out.println("  ");
            }
            int[][] matriceC = {{0, 1, 0}, {0, 1, 0}, {0, 1, 0}};
            Comparer2Matrices comparer2Matrices=new Comparer2Matrices();
            float noteRecu=comparer2Matrices.compare2MatricesFunction(papierAnswerArray,matriceC);
            System.out.println("Dans la classe Rectangle2 : La note recu par l'etudiant E est : "+noteRecu);

            int noteRecuInt=Integer.parseInt(String.valueOf((int)noteRecu));
            Voice e = new Voice();

            switch ( noteRecuInt){
                case 1:
                    e.callNumber(1);
                    break;
                case 2:
                    e.callNumber(2);
                    break;
                case 3:
                    e.callNumber(3);
                    break;

            }
            Boolean isDataNoteAdded =xls_reader2.setCellData(sheetName, columnNoteToAdd,rowNumber+1,String.valueOf(noteRecu));

            extractANDDataSaveExcel();



            Imgcodecs.imwrite(filePath+"resultat.jpg", resultat);
            Imgcodecs.imwrite(filePath+"destination.jpg", destination);

        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
        }
    }
    public static void extractANDDataSaveExcel(){
        System.out.println("Start recognize text from image");
        long start = System.currentTimeMillis();

        origin = Imgcodecs.imread(SRC_PATH+"image1.jpg", Imgcodecs.IMREAD_ANYCOLOR);// transforme l'image en matrice

//
        Map<String,String> resultMap = new RecognizeText().extractTextFromImage(origin,250,240,865-250,339-240,250,240+100,865-250,339-240);


        if (!xls_reader2.isSheetExist(sheetName)){
            xls_reader2.addSheet(sheetName);
        }


// To do just the first time of the sheet
//        Boolean isColumnIdAdded=xls_reader2.addColumn(sheetName, columnIdToAdd);// NB: you have to close the sheet first
//        Boolean isColumnNomAdded=xls_reader2.addColumn(sheetName, columnNomEtudiantToAdd);// NB: you have to close the sheet first
//        Boolean isColumnNoteAdded=xls_reader2.addColumn(sheetName, columnNoteToAdd);// NB: you have to close the sheet first
//        Boolean isColumnMoyenneAdded=xls_reader2.addColumn(sheetName, columnMoyenneToAdd);// NB: you have to close the sheet first
//
//        System.out.println("Column "+ columnIdToAdd +" is added : " + isColumnNomAdded );

        Boolean isDataIdAdded =xls_reader2.setCellData(sheetName, columnIdToAdd,rowNumber+1,resultMap.get("IdEtudiant"));
        Boolean isDataNomAdded =xls_reader2.setCellData(sheetName, columnNomEtudiantToAdd,rowNumber+1,resultMap.get("NomEtudiant"));
//        Boolean isDataMoyenneAdded =xls_reader2.setCellData(sheetName, columnMoyenneToAdd,rowNumber+1,resultMap.get("IdEtudiant"));


        System.out.println("Data added at column "+ columnIdToAdd +" and line : "+(rowNumber+1) +" is "+isDataNomAdded);

        System.out.println(resultMap.get("IdEtudiant"));
        System.out.println(resultMap.get("NomEtudiant"));
        System.out.println("Time");
        System.out.println(System.currentTimeMillis() - start);
        System.out.println("Done");
    }

    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
                    VideoClass frame = new VideoClass();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public VideoClass() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1230, 679);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(176,196,222));
        panel.setBounds(0, 0, 1212, 632);
        contentPane.add(panel);

        Start = new JButton("  Start");
        Start.setBounds(1062, 13, 138, 39);
        Start.setIcon(new ImageIcon("C:\\Users\\Mariam Tiotio Berthe\\Desktop\\PFA\\image\\demarrer.jpg"));

        panel.setLayout(null);
        Start.setFont(new Font("Tahoma", Font.BOLD, 16));
        panel.add(Start);
        Start.setVisible(false);
        checkBoxTelephoneConnecte=new JCheckBox("Telephone connecté");
        b1 = new JButton("Nouvelle Session");
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                webSource = new VideoCapture(Integer.parseInt(textFieldIpChemin.getText())); // video capture from default cam
                myThread = new Tracking(); //create object of threat class
                Thread t = new Thread(myThread);
                t.setDaemon(true);
                myThread.runnable = true;
                t.start();                 //start thrad
                System.out.println("start");
                checkBoxTelephoneConnecte.setSelected(true);

            }
        });

         textFieldIpChemin=new JTextField();
        video = new JPanel();
        video.setBounds(0 , 0 ,
                550, 450);
        panel.add(video);
        video.setLayout(null);
         b2 = new JButton("Capturer");
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ImageIcon image = new ImageIcon(new JPanelOpenCV().MatToBufferedImage(frame));
//              video.setIcon(image);

                video.repaint();
                System.out.println("Captured Frame Width " +
                        frame.width() + " Height " + frame.height());
                Imgcodecs.imwrite("C:\\Users\\hp\\Documents\\S4_2ITE\\PFA\\codes\\PFAMoukrimeIbrahimNewVersionWindows_Dimanche_19_Juin_2020\\PFAMoukrimeIbrahimNewVersion_Dimanche_07_Juin_2020\\Images\\ImagesNewFolder\\imageCapture.jpg", frame);
                System.out.println("OK");

                JFrame jframe = new JFrame("Image capture");
               // jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                JLabel vidpanel = new JLabel();

                jframe.add(vidpanel);
                vidpanel.setBounds(18,39,130,130);
                jframe.setSize(420, 530);
                jframe.setVisible(true);
                ImageIcon imageCapture = new ImageIcon(new JPanelOpenCV().MatToBufferedImage(frame));
                vidpanel.setIcon(imageCapture);
                vidpanel.repaint();
                  return; //arrete sur la vidoe sur la derniere frame = photo
            }
        });

        b3 = new JButton("Lancer la correction");
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               Rectangle2 rectangle2=new Rectangle2();
               correctionFunction();
               nombreCopieRestant=nombreCopieRestant-1;
                checkBoxNombreCopieRestant.setText(nombreCopieRestant+" Etudiant restant");
                if (nombreCopieRestant==0){
                    checkBoxNombreCopieRestant.setSelected(true);
                    checkBoxNombreCopieRestant.setText(nombreCopieRestant+" Etudiant restant Termine ");
                    b1.setEnabled(false);
                    b2.setEnabled(false);
                    b3.setEnabled(false);

                    //checkBoxNombreCopieRestant.setEnabled();
                }
            }
        });

        checkBoxNombreCopieRestant=new JCheckBox(nombreCopieRestant+" Etudiant restant");
        b4 = new JButton("Traitement statistique");
        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                b1.setEnabled(true);
                b2.setEnabled(true);
                b3.setEnabled(true);
                List<String> noteArray= new  ArrayList<>();
                float somme=0;
                for(int i=2;i<=rowNumber;i++){
                   String note=  xls_reader2.getCellData(sheetName,columnNoteToAdd,i);
                   System.out.println("note : "+note);
                   if (!(note=="")){
                       somme=somme+Float.parseFloat( note);
                       System.out.println("somme :"+somme);
                       noteArray.add(note);

                   }
                }
                float moyenne=somme/rowNumber;
                System.out.println("Moyenne :"+moyenne);
                xls_reader2.setCellData(sheetName,columnMoyenneToAdd,rowNumber+1,String.valueOf(moyenne));
                for(int i=2;i<=rowNumber;i++){
                    String note= xls_reader2.getCellData(sheetName,columnNoteToAdd,i);
                    if (!(note=="")){
                        float noteInFloat=Float.parseFloat(note);

                        if (noteInFloat>moyenne){
                            System.out.println(setCellStyle(sheetName,columnNoteToAdd,i,"green"));
                            setCellStyle(sheetName,columnIdToAdd,i,"green");
                            setCellStyle(sheetName,columnNomEtudiantToAdd,i,"green");


                        }


                    }
                }
            }
        });

        panel.add(b1);
        panel.add(textFieldIpChemin);
        panel.add(b2);
        panel.add(checkBoxTelephoneConnecte);

        panel.add(b3);
        panel.add(checkBoxNombreCopieRestant);
        panel.add(b4);

        b1.setBounds(600 , 0 ,
                150, 30);

        textFieldIpChemin.setBounds(600,50,150,30);

        b2.setBounds(600 , 100 ,
                150, 30);

        checkBoxTelephoneConnecte.setBounds(600,175,150,30);

        b3.setBounds(600 , 250 ,
                150, 30);
        checkBoxNombreCopieRestant.setBounds(600,300,150,30);

        b4.setBounds(600 , 350 ,
                150, 30);
        // videoLabel.setBounds(0,0);

    }

    class Tracking implements Runnable {
        protected volatile boolean runnable = false;
        public void run() {
            synchronized (this) {
                while (runnable) {
                    if (webSource.grab()) {
                        try {
                            webSource.retrieve(frame);
                            Graphics g = video.getGraphics();
                            Imgcodecs.imencode(".bmp", frame, mem);
                            Image im = ImageIO.read(new ByteArrayInputStream(mem.toArray()));

                            BufferedImage buff = new BufferedImage(im.getWidth(null),im.getHeight(null),BufferedImage.TYPE_INT_ARGB);
                            buff = (BufferedImage) im;
                            if (g.drawImage(buff, 0, 0, video.getWidth(), video.getHeight(), 0, 0, buff.getWidth(), buff.getHeight(), null)) {
                                if (runnable == false) {
                                    System.out.println("Paused ..... ");
                                    this.wait();

                                }
                            }
                        } catch (Exception ex) {
                            System.out.println("Error!!");
                            ex.printStackTrace();
                        }
                    }
                }
            }
        }
    }
}


