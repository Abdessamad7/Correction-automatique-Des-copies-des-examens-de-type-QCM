import java.awt.Container;
import java.awt.Insets;
import java.awt.Dimension;
import javax.swing.*;

public class AbsoluteLayoutDemo {
    public static void addComponentsToPane(Container pane) {
        pane.setLayout(null);

        JButton b1 = new JButton("Nouvelle Session");
        JTextField textFieldIpChemin=new JTextField();
        JButton b2 = new JButton("Capturer");
        JCheckBox checkBoxTelephoneConnecte=new JCheckBox("Telephone connecté");

        JButton b3 = new JButton("Lancer la correction");
        int nombreCopieRestant=30;
        JCheckBox checkBoxNombreCopieRestant=new JCheckBox(nombreCopieRestant+" Etudiant restant");
        JButton b4 = new JButton("Traitement statique");

        JLabel videoLabel=new JLabel();


        pane.add(b1);
        pane.add(textFieldIpChemin);
        pane.add(b2);
        pane.add(checkBoxTelephoneConnecte);

        pane.add(b3);
        pane.add(checkBoxNombreCopieRestant);
        pane.add(b4);
        pane.add(videoLabel);

        //Insets insets = pane.getInsets();
        //Dimension size = b1.getPreferredSize();
        //System.out.println(insets.toString());
        //System.out.println("b1 size "+size.toString());

        b1.setBounds(600 , 0 ,
                150, 30);

        textFieldIpChemin.setBounds(600,50,150,30);

        b2.setBounds(600 , 100 ,
                150, 30);

        checkBoxTelephoneConnecte.setBounds(600,175,150,30);

        b3.setBounds(600 , 250 ,
                150, 30);
        checkBoxNombreCopieRestant.setBounds(600,300,150,30);

        b4.setBounds(600 , 350 ,
                150, 30);
       // videoLabel.setBounds(0,0);
        videoLabel.setBounds(0 , 0 ,
                550, 450);
    }

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("AbsoluteLayoutDemo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set up the content pane.
        addComponentsToPane(frame.getContentPane());

        //Size and display the window.
       // Insets insets = frame.getInsets();
        frame.setSize(800 ,
                600 );
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}