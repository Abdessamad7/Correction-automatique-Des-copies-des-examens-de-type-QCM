import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Rect;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class getPixelOfImageFunction {
    public double getPixelSum(Mat mat) {
        Mat destinationMat = new Mat(mat.rows(), mat.cols(), mat.type());
        Imgproc.cvtColor(mat, destinationMat, Imgproc.COLOR_RGB2GRAY);
        int rows = destinationMat.rows(); //Calculates number of rows
        int cols = destinationMat.cols(); //Calculates number of columns
        double sommePixelIJ = 0;
        //System.out.println("Nous sommes au contours : " );

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {

                double[] onePixelValuesArray = destinationMat.get(i, j); //Stores element in an array
                int sumOnePixelValuesArray = 0;

                for (double value : onePixelValuesArray) {
                    sumOnePixelValuesArray += value;
                }
                sommePixelIJ = sommePixelIJ + sumOnePixelValuesArray;
            }
        }

        return sommePixelIJ /(rows*cols);
    }

    public double getPixelSum(String chemin) {
        Mat mat = Imgcodecs.imread(chemin, Imgcodecs.IMREAD_ANYCOLOR);
        Mat destinationMat = new Mat(mat.rows(), mat.cols(), mat.type());
        Imgproc.cvtColor(mat, destinationMat, Imgproc.COLOR_RGB2GRAY);
        int rows = destinationMat.rows(); //Calculates number of rows
        int cols = destinationMat.cols(); //Calculates number of columns
        double sommePixelIJ = 0;
        //System.out.println("Nous sommes au contours : " );

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {

                double[] onePixelValuesArray = destinationMat.get(i, j); //Stores element in an array
                int sumOnePixelValuesArray = 0;

                for (double value : onePixelValuesArray) {
                    sumOnePixelValuesArray += value;
                }
                sommePixelIJ = sommePixelIJ + sumOnePixelValuesArray;
            }
        }

        return sommePixelIJ /(rows*cols);
    }

    public static void main(String [] args){
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        getPixelOfImageFunction getPixelObject=new getPixelOfImageFunction();
       // System.out.println("la moyenne en pixel de cette image est : " +getPixelObject.getPixelSum("/Users/nouhou/Documents/ImageNoirTest.png"));

        // Avec cette image : "/Users/nouhou/Documents/ImageNoirTest.png" donne 0.09 == 0 == Noir
    }
}
