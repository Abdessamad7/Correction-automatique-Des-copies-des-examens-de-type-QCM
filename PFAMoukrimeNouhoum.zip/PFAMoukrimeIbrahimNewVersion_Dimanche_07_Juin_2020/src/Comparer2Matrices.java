import java.util.Arrays;

public class Comparer2Matrices {
    public float compare2MatricesFunction( int[][] matriceEleve,int[][] matriceCorrect){
        float note=0;
        float NOTE_MAX=3;
        int numberOfRows = matriceCorrect.length;
        int numberOfColums = matriceCorrect[0].length;
        boolean matriceEgals=false;

        for (int i =0; i<numberOfRows;i++){
            System.out.println("Comparer2Matrices at i = "+i);
            if (Arrays.equals(matriceEleve[i],matriceCorrect[i])){
                matriceEgals=true;
                note=note+1;
                System.out.println("la question "+ (i+1)+" est valide ");
            }else {
                System.out.println("la question "+ (i+1)+" n'est pas valide ");
                matriceEgals=false;
            }
        }

        if (matriceEgals==true){
            System.out.println("Yes");
            note=NOTE_MAX;
            return note;
        }else {
            System.out.println("No");
            return note;
        }

    }
    public static void main(String [] args){
        Comparer2Matrices comparer2Matrices=new Comparer2Matrices();
        int[][] matriceE = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        int[][] matriceC = {{0, 1, 0}, {0, 1, 0}, {0, 1, 0}};

        System.out.println("matriceE  ");
        for (int i=0;i<3;i++){
            for (int j=0;j<3;j++){
                System.out.print(matriceE[i][j]+"  ");
            }
            System.out.println("  ");
        }
        System.out.println("matriceC  ");

        for (int i=0;i<3;i++){
            for (int j=0;j<3;j++){
                System.out.print(matriceC[i][j]+"  ");
            }
            System.out.println("  ");
        }
        float noteRecu=comparer2Matrices.compare2MatricesFunction(matriceE,matriceC);
         System.out.println("La note recu par l'etudiant E est : "+noteRecu);
    }
}